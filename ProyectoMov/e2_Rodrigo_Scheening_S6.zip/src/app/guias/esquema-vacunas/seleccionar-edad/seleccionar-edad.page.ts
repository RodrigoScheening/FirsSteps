import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seleccionar-edad',
  templateUrl: './seleccionar-edad.page.html',
  styleUrls: ['./seleccionar-edad.page.scss'],
})
export class SeleccionarEdadPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
