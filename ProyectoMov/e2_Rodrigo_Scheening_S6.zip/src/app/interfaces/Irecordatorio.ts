export interface Irecordatorio {
    id: number;
    texto: string;
    hora: string;
}
