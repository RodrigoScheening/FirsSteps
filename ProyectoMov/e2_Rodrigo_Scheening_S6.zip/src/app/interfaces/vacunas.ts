export interface Vacunas {
    id: number,
    nombreVacuna: string,
    edad: string,
    protegeContra: string

}
