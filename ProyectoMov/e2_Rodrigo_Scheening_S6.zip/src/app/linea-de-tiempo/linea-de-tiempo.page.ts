import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linea-de-tiempo',
  templateUrl: './linea-de-tiempo.page.html',
  styleUrls: ['./linea-de-tiempo.page.scss'],
})
export class LineaDeTiempoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
